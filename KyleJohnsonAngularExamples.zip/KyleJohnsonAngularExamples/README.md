### Default Error Message Component
This component is meant to deliver consistent error messaging in Material inputs accross an application.
Normally, Material inputs accept `<mat-error>` elements that will display when the element is not valid.
With multiple validators on a control, you'd need to `*ngSwitch` the errors to match the validators, and markup
gets noisy very quickly.

This 'directive' takes in a list of messages tied to error states and displays them accross the application
consistently, so you'd get the same message for a 'required' validator without manually adding it in markup.

Custom validators can also be used with their own messages supplied, and the directive accepts an input object
of { [key: ErrorName]: ErrorMessage } to override default error messages at the form control level.

I had taken this out of a work application (it is also available on github as a packaged module: https://github.com/joh04667/material-error-messages).
Angular Material has since been updated and has changed some APIs, but this project is written for a prior version (6.0).


### Google Charts Module
This is an Angular wrapper for using the Google Charts packages. There are a lot of broken references here as it was lifted out of our application,
so it won't compile, but hopefully things still make sense.
We have a page with about nine of these in gadgets with date pickers; our backend API sends the chart data in JSON format 
(a proprietary format that the chart can consume) and a service above the chart streams the results to all charts through an Observable.
