import { ValidatorFn, Validators as Default, AbstractControl } from '@angular/forms';



export class Validators extends Default {


	/**
	 * @static
	 * @param {number[]} set Set of values that the control shouldn't match.
	 * @returns {ValidatorFn}
	 * @memberof Validators
	 **/
	public static uniqueInSet(set: Set<string>): ValidatorFn {
		return (control: AbstractControl): { [key: string]: any } => {
			const val = control.value;
			return set.has(val.trim()) ? { 'uniqueInSet': { val } } : null;
		}
	}
	/**
		 * @static
		 * @param  Should not be over 50 characters.
		 * @returns {ValidatorFn}
		 * @memberof Validators
		 **/
	public static lessThan50char(control: AbstractControl): { [key: string]: any } {
		return control.value.length < 50 ? null : { 'lessThan50char': false };

	}
	/**
			 * @static
			 * @param  Contains only white space.
			 * @returns {ValidatorFn}
			 * @memberof Validators
			 **/
	public static noWhitespace(control: AbstractControl) {
		const isWhitespace = (control.value || '').trim().length === 0;
		const isValid = !isWhitespace;
		return isValid ? null : { 'noWhitespace': true };
	}

	/**
	 * @static
	 * @param {AbstractControl} control
	 * @returns {{ [key: string]: any }}
	 * Tests to see if form value is numeric. Can be validated with stock pattern validator,
	 * but having a separate validator here will make it easier for error messages.
	 * @memberof Validators
	 */
	public static numeric(control: AbstractControl): { [key: string]: any } {
		return /^[0-9]+$/.test(control.value) ? null : { 'numeric': false };
	}


	/**
	 * @static
	 * @param {(number | string)} [defaultVal] Provided default calue to check. Uses first given value if none are passed.
	 * @returns void
	 * This is NOT a 'Validator', but its usefulness here was too hard to pass up.
	 * This function will mark a control as pristine if the value selected was its original value.
	 * It will never return an error.
	 * @memberof Validators
	 */
	public static notDirtyIfDefault(defaultVal?: number | string) {
		let d = defaultVal;
		let checked = false;
		return (control: AbstractControl) => {

			if (!checked) {
				d = control.value;
				checked = true;
			}

			return control.value === d ? control.markAsPristine() : {}
		}
	}



	constructor() { super(); }



}


/**
 * Class of defaulted error messages to use with the NactErrorMessages directive.
 * fieldName will be passed in or defaulted.
 *
 * When added as a method, will be passed error object for that error.
 *
 * @export
 * @class DefaultErrorMessages
 */
export class DefaultErrorMessages {

	required: string;
	uniqueInSet: string;
	numeric: string;
	noWhitespace: string;


	constructor(public fieldName = 'field') {
		this.required = `${this.fieldName} is required.`;
		this.uniqueInSet = `${this.fieldName} must be unique.`;
		this.numeric = `${this.fieldName} must be numeric.`;
		this.noWhitespace = `${this.fieldName} is required`;
	}

	maxlength(err: any) {
		return `Max length is ${err.requiredLength} characters.`;
	}
}
