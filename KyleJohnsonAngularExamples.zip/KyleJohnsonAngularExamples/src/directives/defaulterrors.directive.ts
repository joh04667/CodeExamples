import { AfterViewInit, Component, HostBinding, Injector, Input, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormControlName } from '@angular/forms';
import { MatInput, MatFormField, MatFormFieldControl } from '@angular/material';
import { DefaultErrorMessages, Validators } from '../shared/nactvalidators';


/**
 * This 'directive' will display default app error messages in an <mat-error> element
 * contained in an <mat-input-container>.
 * @Usage:  <mat-input-container>
 * 				<mat-error nactErrorMessages></mat-error>
 * 			</mat-input-container>
 *
 * ** The input *must* be a FormControl and part of a FormGroup with Validators assigned to it.
 *
 * @Input clientMessages: An object whose keys are names of validators and values are error messages.
 * 							Including this will overwrite the default messag for a specific error.
 *
 * @Input fieldName: A string to use as the name of the field in the message. The MdInput placeholder
 * 					 is used by default.
 *
 * @class ErrorMessageComponent
 * @implements {AfterViewInit}
 */
@Component({
	// tslint:disable-next-line:component-selector
	selector: '[defaultErrorMessages]',
	template: '{{ error }}'
})
export class DefaultErrorMessageComponent implements AfterViewInit {

	// tslint:disable-next-line:no-input-rename
	@Input('defaultErrorMessages') clientMessages: any;

	@Input('fieldName') fieldName: string;

	error = '';
	inputRef: MatFormFieldControl<MatInput>;

	errorList: any;

	public get formErrors(): any {
		return this.inputRef.ngControl.errors;
	}

	constructor(public inj: Injector, public view: ViewContainerRef) { }


	// This grabs a single active error instead of multiple. Might use Maps in the future
	// to prioritize errors, since Maps are indexed.
	updateErrors = (state: 'VALID' | 'INVALID') => {
		if (state === 'INVALID') {
			const firstError = Object.keys(this.formErrors)[0];
			const messageGetter = this.errorList[firstError];

			this.error = typeof messageGetter === 'function'
					? messageGetter(this.formErrors[firstError])
					: messageGetter;
		}
	}

	ngAfterViewInit() {
		this._getInputRef();
		this.fieldName = this.fieldName ? this.fieldName : this.inputRef.placeholder;
		this.errorList = this._createErrorList();
		this._trySubToChanges();
	}

	// grab reference to MatInput directive, where form control is accessible.
	private _getInputRef() {
		let container = this.inj.get(MatFormField);
		this.inputRef = container._control;
	}

	// Overwrite the default messages with supplied messages from the input.
	// We use a spread operator instead of Object.assign to retain getters and setters.
	private _createErrorList(): DefaultErrorMessages {
		if (!this.clientMessages || typeof this.clientMessages !== 'object') {
			return new DefaultErrorMessages(this.fieldName)
		}
		let errorList = new DefaultErrorMessages(this.fieldName);
		return { ...errorList, ...this.clientMessages };
	}

	private _trySubToChanges() {
		if ( !this.inputRef.ngControl ) { return console.error(`defaultErrorMessages: No FormControl registered for ${this.fieldName}!`) };

		this.inputRef.ngControl.statusChanges.subscribe(this.updateErrors);
	}
}

