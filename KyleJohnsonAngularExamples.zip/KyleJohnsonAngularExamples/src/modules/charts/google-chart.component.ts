import { Component, Input, ElementRef, HostListener, EventEmitter, Output, ViewChild, ChangeDetectionStrategy, ChangeDetectorRef, NgZone } from '@angular/core';
import { GoogleChartLoaderService } from './google-chart-loader.service';
import { ChartNames, GoogleChartTypes, GoogleChartOptionTypes } from '../../enums/chart-types.enum';
import { Utils } from 'app/shared/utils';
import { DataType, RiskLevel, DataModelBase, DateSelectionOption } from '../../dtos/company.dtos';
import { DashboardStore } from '../../stores/dashboard.store';
import { DataTypeCharts } from '../../features/dashboards/chart-options/chart-types';
import { ChartOptionService } from '../../features/dashboards/chart-options/chart-options.service';
import { Observable } from 'rxjs';

import Charts = google.visualization;

@Component({
	selector: 'nact-google-chart',
	templateUrl: './google-chart.component.html',
	styleUrls: ['./google-chart.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class GoogleChartComponent {

	private _dataType: DataType;
	private _type: keyof typeof ChartNames;
	private _options: Object;
	public chart: Charts.ChartWrapper;
	public table: Charts.DataTable;
	public gridReady = false;
	public showOverlay = false;
	public overlayMessage = 'Loading...';
	public riskLevel: RiskLevel;


	@ViewChild('chartContainer') chartContainer: ElementRef;

	// Listen for a resize and redraw the chart to the new size. The debounce is to buffer redraws.
	@HostListener('window:resize', ['$event'])
	onResize = Utils.debounce((event) => {
		this.redraw();
	}, 100);


	// DataType should be a key of the DataType enum.
	@Input('dataType') set dataType(val: DataType) {
		this._dataType = val;
		this._setDataSource();
		this._getChartOptionsForType();
	}

	@Output('ready') ready = new EventEmitter<boolean>();

	constructor(
		public el: ElementRef,
		public loader: GoogleChartLoaderService,
		private dataStore: DashboardStore,
		private _changeDetectorRef: ChangeDetectorRef,
		public zone: NgZone,
		public optionsService: ChartOptionService) {
	}

	// If the date range is changed, we only need a new data set for this gadget.
	public setDateRange(dates: DateSelectionOption) {
		this._showOverlay('Loading...');
		this.dataStore.getSingleDataSetForStore(this._dataType, dates)
			.pipe(this._handleDataStream())
			.subscribe(s => {
				return s ? this.setupChart(s) : (this._showOverlay(), this._clearChart());
			});
	}


	public async setupChart(data) {

		if (typeof data !== 'string') { return; }

		// if there's data and the overlay needs to go, do some change detection
		if (data && this.showOverlay) {
			this.showOverlay = false;
			this._changeDetectorRef.detectChanges();
		}

		// The service loads the chart library and completes an Observable when the script has loaded. Better than subbing every time.
		if (!this.loader.loaded.isStopped) { await this.loader.loaded.toPromise(); }

		this.zone.runOutsideAngular(() => {

			// If the component is given no chart type, resolve the correct chart from the data type.
			if (!this._type && this._dataType) {
				this._type = DataTypeCharts[DataType[this._dataType]] || 'Table';
			}

			this.table = new google.visualization.DataTable(data);

			this._options['table'] = this.table;

			// if no chart yet, we can do some initial setup
			if (!this.chart) {
				// this.chart = new google.visualization[this._type](this.chartContainer.nativeElement);
				this.chart = new google.visualization.ChartWrapper({ chartType: this._type, containerId: this.chartContainer.nativeElement, dataTable: this.table, options: this._options });
				this._options['currentChartSize'] = this.chartContainer.nativeElement.getBoundingClientRect();
			}

			this.chart.setDataTable(this.table);

			if (!this.gridReady) {
				google.visualization.events['addListener'](this.chart, 'ready', () => {
					this.ready.emit(true);
					this.gridReady = true;
				});
			}

			this.chart.draw();

		});
	}


	public redraw(animation = false) {
		// set new chart area on the options. Right now, redraws happen for resize events -- refactor this if that scope changes
		this._options['currentChartSize'] = this.chartContainer.nativeElement.getBoundingClientRect();
		// if no chart, don't try to draw it dummy. also don't try if the chart it currently cleared.
		if (!this.chart) { return; }

		let current = this.chart.getOption('animation');

		if (!animation) {
			this.chart.setOption('animation', {});
		}

		this.chart.draw();

		this.chart.setOption('animation', current);
	};

	private _showOverlay(message = 'No Data To Show') {
		// Emit a ready event for animation, even though no data.
		this.ready.emit(true);

		this.showOverlay = true;
		this.overlayMessage = message;
		// the change detection strategy is a speedup, but we'll need to manually check little stuff like this.
		this._changeDetectorRef.detectChanges();
	}

	private _clearChart() {
		// dunno why this type doesn't include clear, but it's definitely on ChartWrapper
		return this.chart && this.chart['clear']();
	}

	private _setDataSource() {
		this.dataStore.loading
			.distinctUntilChanged()
			.subscribe(s => !s || this._showOverlay('Loading...'));

		this.dataStore.getDashboardDataSet(this._dataType)
			.pipe(this._handleDataStream())
			.subscribe(s => {
				return s ? this.setupChart(s) : (this._showOverlay(), this._clearChart());
			});
	}

	private _getChartOptionsForType() {
		this._options = this.optionsService.getChartOptions(this._dataType);
	}

	// Lettable operators are cool. Let's just re-use this sream of side effects.
	private _handleDataStream(): (source: Observable<DataModelBase>) => Observable<string> {
		return (source) => source
			.pipe(
        tap(s => this.riskLevel = s.RiskLevel),
        map(s => JSON.stringify(s['Data']))
      );
	}

}

function isChartType(s: any): s is ChartNames {
	return typeof s === 'number' && !!ChartNames[s];
}






