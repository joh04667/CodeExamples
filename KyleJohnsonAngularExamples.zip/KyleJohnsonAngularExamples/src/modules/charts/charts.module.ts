import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoogleChartComponent } from './google-chart.component';
import { GoogleChartLoaderService, ChartConfigFactory, CHART_PACKAGES, PACKAGE_LOAD_STATUS } from './google-chart-loader.service';
import { FlexLayoutModule } from '@angular/flex-layout';




@NgModule({
	imports: [
		CommonModule,
		FlexLayoutModule,
	],
	declarations: [GoogleChartComponent],
	providers: [],
	exports: [GoogleChartComponent],
})
export class ChartsModule {

	// Set the needed chart packages to be loaded with the module. See https://developers.google.com/chart/interactive/docs/basic_load_libs
	public static withPackages(packages: string[]): ModuleWithProviders {

		// TODO: Currently, AOT will only load this when a component is loaded.

		return {
			ngModule: ChartsModule,
			providers: [GoogleChartLoaderService,
				{ provide: CHART_PACKAGES, useValue: packages },
				{
					provide: PACKAGE_LOAD_STATUS,
					useFactory: ChartConfigFactory,
					deps: [ CHART_PACKAGES ]
					// multi: true
				}
			]
		};

	}
}

