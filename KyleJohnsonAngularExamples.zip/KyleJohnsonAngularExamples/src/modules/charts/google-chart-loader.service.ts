import { BehaviorSubject } from 'rxjs/Rx';
import { Injectable, Injector, InjectionToken } from '@angular/core';


declare var google;
export const CHART_PACKAGES: InjectionToken<string[]> = new InjectionToken<string[]>('ChartPackages');
export const PACKAGE_LOAD_STATUS: InjectionToken<BehaviorSubject<boolean>> = new InjectionToken<BehaviorSubject<boolean>>('PackageLoadStatus');


// This service is meant to be run as part of app initialization, so charts will be able to be drawn regardless of bootstrap/lazy load status.
// It will emit a loaded event once the Google chart library is available.
@Injectable()
export class GoogleChartLoaderService {

	loaded: BehaviorSubject<any>;
	packages: string[]

	static Load(packages) {
		let loaded = new BehaviorSubject<boolean>(false);

		if (typeof google !== 'undefined' && google.charts) { return; }

		let script = document.createElement('script');
		script.type = 'text/javascript';
		script.src = 'https://www.gstatic.com/charts/loader.js';

		script.onload = () => {
			google.charts.load('current', { packages: packages });
			google.charts.setOnLoadCallback(function () {
				// Set the material bar graph to visualization instead as a polyfill.
				if (packages.includes('bar')) { google.visualization['Bar'] = google.charts['Bar']; }
				if (packages.includes('line')) { google.visualization['Line'] = google.charts['Line']; }


				loaded.next(true);
				loaded.complete();
			});
		}

		document.getElementsByTagName('head')[0].appendChild(script);

		return loaded;

	}

	constructor(public injector: Injector) {
		this.packages = injector.get(CHART_PACKAGES);
		this.loaded = injector.get(PACKAGE_LOAD_STATUS);
	}



}

export function ChartConfigFactory(packages: any) {
	return GoogleChartLoaderService.Load(packages);
}
