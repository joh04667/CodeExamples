﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Amazon;
using Amazon.KeyManagementService;
using Amazon.KeyManagementService.Model;
using AWS_KMS_payload_decryptor;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AWS_KMS_payload_decryptor_tests
{
    [TestClass]
    public class KMSPayloadDecryptorShould
    {
        protected const string AWS_ACCESS_KEY_ID = "REDACTED";
        protected const string AWS_SECRET_ACCESS_KEY = "REDACTED";
        // Benchmark data
        protected const string ENCRYPTED_KEY = "AQEDAHjRL7rvmtPKRwgXYSONS9T9G+qUEXpQAb1MZOqyYkHCQwAAAH4wfAYJKoZIhvcNAQcGoG8wbQIBADBoBgkqhkiG9w0BBwEwHgYJYIZIAWUDBAEuMBEEDHrltusD10iUOEIbJgIBEIA7oaocLgl7IXab2bbyU+A7R1uvmfSm8ZD2BG71/YKEqBtA5byMRMWd9phJNfZ9x+FgdlPvC6X0qdwM/BA=";
        protected const string ENCRYPTED_PAYLOAD = "XAqwwLONQBThpTC44C65yqGbqCsQl5+LlAllpVWbSLN3gfQHcdL8rdHAc6Uh6N9reLhtxVSC6d/0/DHK6NFunVRk4rPPTTfE1tk3tHrSEMKVJf5OFXD7WooiBQOthp0lU8VGRovM/Gu+p4iIBpTKfyI/bRvg8ME7dLSxqgMNYoV6AvBU0nmpCe5/7T+DNLZehfMa89FMH0QiBXG1A6gP2fIjqnvCwxKr1VvqJTVBRBLevIW4K6YMsGVW37RKE0XeFed5UVI7mbowO9jZVFL/E7/4nRIRScTo86w/MTRgsJkeK4E8OlqShu0Npe7awPmHauCNO7zhdtN/pi5w8wXhfQraqUFc3sGNN7a/TYnRjZI6/+0C6wEhdCMxGV+0XzR62YxDQ6Meqz4hQMddcSVQyjkLHcmNtZ4y15bKW1EsWHNYzmaaGgAYYjFfcCCcLwcMQpMAvSYVwIlz7LQBdvQuFi/dlcI/SbPRYgAokvjVVunQ0l+0hdHjh5cxir6Sygy9Z5plTE98SwbxboveQLyFCg3fFNv+1MR++1SYxPKBY2Jd1SxUrIK7k2/+UORFrP4BskIaznYEicD/LvrB4RzC84t8FiqN5eUgMDUzqdPNFPmz3MLA2fMLXupQoSQABJJxncyxBxxgTGQMJ1eZKRuLNSvJ3awp5U58ytsjFN6tIsxQGboe0nrBBLt8CMgHLeZj1yTYp0tWZk24OWG3tQruRvocoOONZR0Ac0uaJY3lkGntURqaUaR5ddrwzKafJsEI9y1AVl8vlpAT9f5JaEa1cCaxztWFkRqTIkOUDiCRh49eRYh9liYXIdudFp8rECLHaUIlUHSDNmiU8hICenNWdnTQQTg7g2BY9Wb4ATtjg8MQRNyn9nQXIqd35ItIzdIQOhHlXfGotwbUCwCYX3d8eB9pAvbRpYBTUMX1k47mWagFHT7aUCEWpbeQ1/cdmgc0hmZUHJIvOZiDlMjcivL66dmj55zb1+AjJ0ES/i3yYT+kjajPLXqJSQLeASdNwvz9Q8AUXktPyvQD0nU8zKNhYxJVzoHZeiwQvLTul1ikSJDKEumOehXbxVVDJAmBgzEgiA6ZRBQXzEYZlXDoeD/Qsw==";
        // Some 'live' data off a real message...it's far more meaty (check length) but requires kms:Decrypt for the PROD key.
        //const string ENCRYPTED_KEY = "AQEDAHjRL7rvmtPKRwgXYSONS9T9G+qUEXpQAb1MZOqyYkHCQwAAAH4wfAYJKoZIhvcNAQcGoG8wbQIBADBoBgkqhkiG9w0BBwEwHgYJYIZIAWUDBAEuMBEEDPDYENWJVhcUi2FdNQIBEIA7RnYwSb5/VH2uNCqBE9tdZ7unClqnop1fX2faPebLTptHt0e0a08j1od2LoKLnPG0746pu7SAOm51iW0=";
        //const string ENCRYPTED_PAYLOAD = "jT7RxG6P451JBkA2mjseEg8c3A6v6vQ5p3/YQFetGob3hFh1zgtcel1f1uWncxLtjpA/3pdd9ekZHI1KW2ozWkEDCg2r+6UAVhiVWfsevl+lvTL+vw/j5H9+zDwgcFEuzC1EZdL+RJdkx8SAM7OqCx0a6vEUM7ZlD58PlJttSBLJgM3Une/hQEPgLSHzL4V3D2prQhRX066ohxWo4UdRElDD8HSifE0UE7YuBCvnnNPjCo9zhYfg601qXHiter2oiI81AejEd1s6dzxPwJMCAOa3GK1w+4kFZv9fjgbrUCg+laQ6vHn7mezo19E6G44IrF4nohdBchWM0E3twxUutLXTLJQmDEkOBwKHNuJX/kvraqdVsjxuvzWzCgHCD/htd1A0zv2cq6ciEybgs6hOyZVQ1A1BpEnA5X7ihHqpuvy+0P/Pu2DkRRg3OqOf4HDiXO59S3B+ZBb8hlyGXQmqTZ67o6YR4ht98w7Wo2ypmrTk0IRyVcwbiDMjvO2sGlo0eOgLtsrN1BA46Pg61c+5UYlfiDy2DiCm0TypeBN2gxNZd3HM883LwjE/K/8LLwnnedqTbdoj+YD3gTnsVoIYMGFWQ/dfiwNpppt4woLfCOM8RaaV3GqW0gm5qOR1VXvuUpVXjwtFcIA99Tug4bvgH0+2yQNBLo4ZV1XPqsT1rDl/L/bO9BU1dT5DaMdAPoyZcqmDIve8Gd3GIeE8OY30wMI0k72kOqdKvgDyVvkL5MMNB2ETOk4VqLwz+N7a72bGFgDc6jd0QNE2p+5NyteAl1Aldw7T3dP4T/omEaeCf/5fg+Uw1J+XZ8ulCW2xb7H3bxezCCggNW3bWpt/yG/JgqDMASsvVg0icfc4xOyfZW3FnEcYk8Q+EO/6QVCyvvstFSSEZl61Q896j58hw9T/v2CtRHZDuyZAPh2jhBOB3kDvYbyAuf8yDhJNxAgVeUGiE8mnsDTKmm3ICBBam9Mv+9ySQdG/7CNPlm90eYtq9DY+1rp6XNnu7xzhSsmJ5TPP2fiNdB2N7sdLJC2m9uRRglUSx9ZTcr/yBIdvetSqygRJvdu+xaNarHBxjmdtHTShhKX7TbaOFU/nmF8xrAnTdUhf8HZacKGPYBtNr+scWCNMSDzCH0HoTJZKPVnFy8rQCW4Aa9WD0TrGDaoAZb+hIKiRi5KIEskom6+s3SPBY/CoPi7UJRcP8r27tX8Bu+ruWaerDl3xjFQq7eAT0YjkIU11jAmj8r2/jIJzXBWA5SB8qOmkmdDgzU8pduLiDQXvceC3BYrMLE3kC4zn2jJ4aqIkahPLPPv5lWgurd3mjfEi1nvVtg9gjkwq/wkYv1YMACJAgzEGddMshA41eTI9d+yZLPKr289S2WFjzCiyq3Mv0GUQaQPCbq5EFxfs7n1xpb4mFEDbcYxnxcwSjw4L3lpUWMHz1YxlKGsBVSvTKXdVrl8yBJTfBtayF0lC0wV00tl0NYEjjkgjmHBAX7OavKjtJJcjTnyQJNiqHbFR8jGg8aeWkQaSffexG4zop91kYk2zJiUY2JeQu37hwtG3ze9niUJoAxPMFV9bXesqY+o8DWnNRqdlFfxvOjEZ8z+fXWpdOFPz4cSpXdHIntR1c7GrF3RuaM88ieV4iUDo9kdnQ7rbtzH2NqLYxZkZwWVHeGSSDJSOk0xlsrt5uNrtOtvtHZCwzpsG/C+bsntWWs5Eij6C4MALSDEv3PpO29fArtisZmiYmvpPE+DLzd39yG23TLJokIaVO8id383FnIh7F6rSxo/UtMob/A76F16UFuNgxc2ccXH8J4mKorqmkH5W1Kqu+CeFkGDIGLcKc3W9IEUw3LXIC3kD6evJKpJxmlQVcr70ApgiM6YMVEN8FTE+xxw4MMrxP98mt66fad3qiqRyGH54ReU96HHvhPmHuKHV63Zm4bnI5WXyioLJgPNLeREGIuTB152ztjh8ti/vGM8yhPHs0NekrdwvROWIgEv95THWj5E43AHKMbsHXX+CohAMEITr/wK4BsVrvpRcg/W4fqvG/N3/dLQceABnXiwvk0ZQUc8lum7j8yE3i+cCF1m9uQLfhBKFi+TXDNCOFJkPgeKUKkPDR9qDJrFVmFMHlJ1GrXH2X8GnYPSMI84gYi3FtzHkLWDn4qwO7/ciqD3FRbIMfOwPJAes6/tb9Yyp20oLF6f+p8fV52xN6BbqJxkse6FNIEV9xpZgWlTmPu3PPMWhe1KOndrs4fxFRklUdQhMnGw8FK0LygFthy3GQqb8IPHAuT4p58eaPqnd7OsdNdCU7QsPSsmFP7hS3dO76edIai25UH2VXXDl5IaSEKSmIs6ZYq1ss8BfjwwZNLDlLrZWkAY6i5xbeD09WBhWsF5IuZBy6NIUHSFBNwulDAVvqrAgCnsF0+PBnIanwpkWjPgLAo84JGpDC6xldqZg2Q1w6lZgIq50SPXIaWdOgK6PpU+8b2cbtGG0D6Exd+1lrLNcz/KmHWxQUu7naixwfDMTadeUFuA1cbHl8TsNRDw5Lb+vymrqaGTaF4PsWpPToF9/4yQY4CfYDI1dW0YpDMY6YAdHtd/EJjt6+VuhIf4mKgX1zSoINh2SUsgv/+tZawKV6oAEwscgIwEHbWnxCmMleqLtPgHWUrQkam2MOu2D4/KtmYACLHEZi7fiyRMMa6S3eLANxXMNjEE0XKxzFafeaTk5Za6vX/2mR9hRTOTyyin9LUxhmrNpFgDpKI443jPq/Uhm0eZsqnAfWpGLIkDFGPdSReAf5yMvm7JdbYL+qoWkrMiKh5IUN1BuOXkOvB7M1Km/enfCveSM7Z3w572cmCfBD7ldWDHQcnJBmfdB+d8ENvKJkEWkS0Rq+1AIJ/vJT7tBjkLTMwrTCzf+g8vChk3qUx0YIDVzr5yQhtcSVm4oeaSzNP93NQc+6QrYIfqkrXEdKDoCC4O14xQCFwqbw8MMMTr5snO97i381BhNZ5a6J8kOTQRoTpbLSgHfVcd5sruE7nC3pA8caL0huVdWY1DzScrDk88JMDqTtEdO10nn2V/stbP+oXGbApl3tfxAMB170i5UhD93us+HiGjVxy7hoNTwM9XY9ZEx7gL4HLNlBE1BCyoWgZlScUMJqUlU2MUnYclAKpUexuRuHbeE8MFH5L0ydkc9up3gLP8EEyUSNWW1fucKCSU=";
        protected readonly RegionEndpoint REGION = RegionEndpoint.USWest2;




        [TestMethod]
        public void TEST()
        {
            // Arrange
            var kms = new KMSPayloadDecryptor(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);

            // Act
            var res = kms.DecryptCipherText(ENCRYPTED_PAYLOAD, ENCRYPTED_KEY);

            // Assert
            // TODO: We should run tests on input/output of a benchmark example included in the project...since this will not remain its own project, tests will need to be updated.
            // This test is just to debug the decryptor.
            // Assert.IsTrue(true);

        }

        // These tests won't work without the kms.Encrypt policy, which we do not have anymore.
        // Originally, the tests were encrypting control data before testing decryption.
        //[TestMethod]
        //public void AWSLocalEncryptDecryptWorksAsIntended()
        //{
        //    // This just checks our local account(with the given access key)'s KMS encrypting and decrypting.
        //    // Arrange
        //    const string secretMessage = "I am a teapot, short and stout";
        //    var encryptedMessage = TestHelpers.KMSEncryptSampleStringWithKey(secretMessage, KEY_ID, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);
        //    var kms = new AmazonKeyManagementServiceClient(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);

        //    // Act
        //    var res = kms.Decrypt(new DecryptRequest { CiphertextBlob = new MemoryStream(Convert.FromBase64String(encryptedMessage)) });
        //    var str = Encoding.ASCII.GetString(res.Plaintext.ToArray());

        //    // Assert
        //    Assert.AreEqual(secretMessage, str);
        //    Assert.IsTrue(res.KeyId.Contains(KEY_ID)); // The actual key has some metadata on it, just check for the keyId guid
        //    Assert.AreEqual(System.Net.HttpStatusCode.OK, res.HttpStatusCode);
        //}


        //[TestMethod]
        //public void KMSPayloadDecryptorHandlesEnvelopedEncryption()
        //{
        //    // Arrange
        //    // the unencrypted stuff...
        //    const string secretPayload = "I'm going to get my bytes all shifted around...";
        //    var plainTextKey = "1234567890123456";
        //    // The stuff that will have already been done with the payload (encrypted strings, but plaintext)...
        //    var encryptedPayload = Convert.ToBase64String(TestHelpers.EncryptStringFromBytes_AES(secretPayload, Encoding.ASCII.GetBytes(plainTextKey)));
        //    var encryptedKey = TestHelpers.KMSEncryptSampleStringWithKey(plainTextKey, KEY_ID, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);
        //    // and the class itself
        //    var kms = new KMSPayloadDecryptor(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);

        //    // Act
        //    // now, we have two layers of encryption. Key decryption handled through kms, and decrypted key is the AES key for the payload.
        //    // class should handle 'em both
        //    var res = kms.DecryptCipherText(encryptedPayload, encryptedKey);

        //    Assert.IsNotNull(res);
        //    Assert.AreEqual(res, secretPayload);
        //}


        //[TestMethod]
        //public void ConcurrentCallsTogetKeysWillResultInOnlyOneHttpCall()
        //{
        //    // Arrange
        //    var payloadOne = "Jeremiah was a bullfrog";
        //    var payloadTwo = "Country rooooooooooooooooooooooooooadssssssssss, take me hoooooooooooooooooooooooooomme...toooo tha plaaaaace I belooooooooong";
        //    var payloadThree = "Johnny was a race car driver";

        //    var keyOne = "1234567890123456";
        //    var keyTwo = "1122334455667788";
        //    var keyThree = "8877665544332211";

        //    var encKeyOne = TestHelpers.KMSEncryptSampleStringWithKey(keyOne, KEY_ID, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);
        //    var encKeytwo = TestHelpers.KMSEncryptSampleStringWithKey(keyTwo, KEY_ID, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);
        //    var encKeyThree = TestHelpers.KMSEncryptSampleStringWithKey(keyThree, KEY_ID, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);

        //    var encryptedPayload = Convert.ToBase64String(TestHelpers.EncryptStringFromBytes_AES(payloadOne, Encoding.ASCII.GetBytes(keyOne)));
        //    var encryptedPayloadTwo = Convert.ToBase64String(TestHelpers.EncryptStringFromBytes_AES(payloadTwo, Encoding.ASCII.GetBytes(keyTwo)));
        //    var encryptedPayloadThree = Convert.ToBase64String(TestHelpers.EncryptStringFromBytes_AES(payloadThree, Encoding.ASCII.GetBytes(keyThree)));

        //    var loop = new[] { 1,2,3,4,5,6 };
        //    var keys = new[] { encKeyOne, encKeyOne, encKeytwo, encKeytwo, encKeyThree, encKeyThree };
        //    var loads = new[] { encryptedPayload, encryptedPayload, encryptedPayloadTwo, encryptedPayloadTwo, encryptedPayloadThree, encryptedPayloadThree };

        //    var ret = new ConcurrentBag<string>();

        //    // Act
        //    Parallel.ForEach(loop, i =>
        //    {
        //        var kms = new KMSPayloadDecryptor(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, REGION);
        //        ret.Add(kms.DecryptCipherText(loads[i -1], keys[i - 1]));
        //    });

        //    // Assert
        //    var result = ret.ToList();

        //    Assert.IsNotNull(result);
        //    Assert.AreEqual(6, result.Count());
        //    Assert.IsTrue(result.Where(s => s == payloadOne).Count() == 2);
        //    Assert.IsTrue(result.Where(s => s == payloadTwo).Count() == 2);
        //    Assert.IsTrue(result.Where(s => s == payloadThree).Count() == 2);
        //}

    }

    static class TestHelpers
    {

        // since we don't need encryption functionality in the main decryptor class, let's use the underlying service client to encrypt.
        // ofc, this means we should have kms:Encrypt and kms:Decrypt policies.
        public static string KMSEncryptSampleStringWithKey(string input, string keyId, string accessKey, string accessSecret, RegionEndpoint region)
        {
            var kmsClient = new AmazonKeyManagementServiceClient(accessKey, accessSecret, region);
            var encryptedRes = kmsClient.Encrypt(new EncryptRequest { KeyId = keyId, Plaintext = new MemoryStream(Encoding.ASCII.GetBytes(input)) });
            return Convert.ToBase64String(encryptedRes.CiphertextBlob.ToArray());
        }

        public static byte[] EncryptStringFromBytes_AES(string plaintext, byte[] key)
        {
            byte[] ret;

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = key;
                // as far as I know, there's no hashing or salting of this. Leave IV as 00000 for now.
                aesAlg.IV = new byte[128 / 8];

                var encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (var msEncrypt = new MemoryStream())
                {
                    using (var cs = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var sw = new StreamWriter(cs))
                        {
                            sw.Write(plaintext);
                        }
                        ret = msEncrypt.ToArray();
                    }
                }   
            }
            return ret;
        }
    }
}
