#### README

This class was built to handle the on-the-fly decryption of a client's transaction log messages. 
Our client sends us their data in JSON format, with an encrypted payload that contains PII information.
This payload is AES encrypted, and the AES key is further encrypted with AWS KMS.
Decoding the key with KMS is simple enough (just a command line call; all the KMS key info is baked in to the cipher),
but our client cycles these keys every few thousand transactions, and because the data is coming in a trickle feed, the reused keys aren't 
necessarily sequential. 

This class is being used by an army of worker threads working concurrently, and our AWS account is billed per KMS call, so it was important to me
to avoid having concurrent workers repeating KMS calls for the same key (in the case of one already being in-flight). These transactions are processed quickly
(~100 per second), so repeated calls could add up quickly (and hurt performance).

The unit tests in this project required a live AWS account with proper permissions. I was using our development account; this information has been redacted for obvious
reasons, so these tests won't work. Since the KMS keys are also tied to our AWS account, the encrypted information included in the tests will be impossible to decrypt.