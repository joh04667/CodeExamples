﻿using Amazon;
using Amazon.KeyManagementService;
using Amazon.KeyManagementService.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AWS_KMS_payload_decryptor
{
    public class KMSPayloadDecryptor
    {
        // Decrypted keys should be accessible even if new ones are added, so they should be cached in in a static spot.
        // Not using a ConcurrentDictionary wasa a design choice, as using a GetOrAdd with a valueFactory can still result in multiple
        // calls to that valueFactory for the same key, which would make multiple HTTP calls for the same key.
        // See: https://docs.microsoft.com/en-us/dotnet/api/system.collections.concurrent.concurrentdictionary-2.getoradd?view=netframework-4.7.2#System_Collections_Concurrent_ConcurrentDictionary_2_GetOrAdd__1__0_System_Func__0___0__1____0_
        private static Dictionary<string, Task<byte[]>> KeyRing = new Dictionary<string, Task<byte[]>>();
        protected readonly AmazonKeyManagementServiceClient kmsClient;


        public KMSPayloadDecryptor(string awsAccessKey, string awsSecretAccessKey, RegionEndpoint region) {
            kmsClient = new AmazonKeyManagementServiceClient(awsAccessKey, awsSecretAccessKey, new AmazonKeyManagementServiceConfig { RegionEndpoint = region } );
        }

        // there's no salting on the messages so far. This overload just uses a default IV of zeroes.
        public string DecryptCipherText(string base64EncryptedPayload, string base64EncryptedKey)
        {
            return DecryptCipherText(base64EncryptedPayload, base64EncryptedKey, new byte[128 / 8]);
        }

        public string DecryptCipherText(string base64EncryptedPayload, string base64EncryptedKey, byte[] iv)
        {
            // Check arguments.
            if (base64EncryptedPayload == null || base64EncryptedPayload.Length <= 0)
                throw new ArgumentNullException("base64EncryptedPayload");
            if (base64EncryptedKey == null || base64EncryptedKey.Length <= 0)
                throw new ArgumentNullException("base64EncryptedKey");

            Task<byte[]> task = GetDecryptedKey(base64EncryptedKey);
            byte[] Key = task.Result;

            return CryptoHelpers.DecodeEncryptedPayloadAES(base64EncryptedPayload, Key, iv);
        }


        // We should expect any amount of workers with their own instances of this class trying to decrypt text
        // concurrently. Since the KMS decrypt is an HTTP call, workers will be waiting for new keys to be decrypted.
        // Because KMS API calls are how we're charged, we only want to make ONE http call per new key while caching decrypted ones. 
        // The idea is to store the HTTP call itself as a Task. That way, an in-flight call can be represented as a Task
        // and given to any worker requesting the same key. If the call's already finished, the task will be done and can be unwrapped.
        // The lock does NOT last for for the duration of the http call; we're adding a Task for that http call, and creating that Task isn't an async operation.
        private async Task<byte[]> GetDecryptedKey(string key)
        {
            Task<byte[]> task = null;

            lock (KeyRing)
            {
                if (!KeyRing.TryGetValue(key, out task))
                {
                    task = DecryptEncryptedKey(key);
                    KeyRing.Add(key, task);
                }
            }
            
            return await task;
        }

        // again with error handling here. Any errors returned by the client would be 
        // http issues, credential issues, or (probably extremely rarely) malformed cyphers.
        // We'd probably want to be smart about this and retry decrypts when possible.
        private Task<byte[]> DecryptEncryptedKey(string cipherText)
        {
            MemoryStream cipherTextBlob = CryptoHelpers.GenerateStreamFromBase64String(cipherText);
            var dr = new DecryptRequest { CiphertextBlob = cipherTextBlob };

            return kmsClient.DecryptAsync(dr).ContinueWith(t => t.Result.Plaintext.ToArray());
        }
        
    }

    static class CryptoHelpers
    {
        public static MemoryStream GenerateStreamFromBase64String(string input)
        {
            return new MemoryStream(DecodeBase64String(input));
        }

        public static byte[] DecodeBase64String(string input)
        {
            return Convert.FromBase64String(input ?? "");
        }

        // Confirmed with {client_name} that the payload is encrypted using AES ECB with no padding and no salt.
        // Resulting stream of bytes is gzipped, so we need to decompress it first.
        public static string DecodeEncryptedPayloadAES(string encryptedBase64Payload, byte[] Key, byte[] IV)
        {
            string ret = null;

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.KeySize = Key.Length * 8;
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                aesAlg.Padding = PaddingMode.None;
                aesAlg.Mode = CipherMode.ECB;     

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // we just need to decode to bytes, not a string, because of the compression. Wrap the decryption in a memstream that we can copy to.
                using (var dumpStream = new MemoryStream())
                {
                    using (MemoryStream msDecrypt = GenerateStreamFromBase64String(encryptedBase64Payload))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                srDecrypt.BaseStream.CopyTo(dumpStream);
                            }
                        }
                    }
                    ret = Unzip(dumpStream.ToArray());
                }
            }
            return ret;
        }

        public static string Unzip(byte[] bytes)
        {
            using (var memstreamIn = new MemoryStream(bytes))
            using (var memstreamOut = new MemoryStream())
            {
                using (var gs = new GZipStream(memstreamIn, CompressionMode.Decompress))
                {
                    gs.CopyTo(memstreamOut);
                }
                return Encoding.ASCII.GetString(memstreamOut.ToArray());
            }
        }
    }



}
